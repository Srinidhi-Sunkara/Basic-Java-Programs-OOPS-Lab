import java.util.Scanner;
public class Matrix
{

  public static void main(String[] args)
  {
       mat m ;
    m = new mat();
    m.getinput();
    
  }
}
class mat
{   
   int i,j,r,c;
   static int rows;
   static int coloums;

    
   void getinput()
   {
     
	Scanner in = new Scanner(System.in);
   System.out.print("enter the no of rows:");
   rows=in.nextInt();
   System.out.print("enter the no of coloumns:");
   coloums=in.nextInt();
    r=rows;
   c=coloums;
     int[][] a = new int[r][c];
     int[][] b = new int[r][c];
    int[][] d = new int[r][c];
  
   System.out.println("enter the elements");
   for(i=0;i<r;i++)
   { 
     for(j=0;j<c;j++)
      {
         
         a[i][j]=in.nextInt();
      }
   }
 
  System.out.println("enter the elements");
   for(i=0;i<r;i++)
   { 
     for(j=0;j<c;j++)
      {
         b[i][j]=in.nextInt();
      }
   }
   
   
   for(i=0;i<r;i++)
   { 
     for(j=0;j<c;j++)
      {
         d[i][j]=a[i][j]+b[i][j];
      }
   }
    System.out.println("After adding");
   for(i=0;i<r;i++)
   { 
     for(j=0;j<c;j++)
      {
         System.out.print(d[i][j]+" ");
      }
      System.out.println("");
   }
  }
     
   
     
}
