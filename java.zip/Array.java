import java.util.Scanner;
public class Array
{
  public static void main(String[] args)
  {
      int x;
     Scanner in = new Scanner(System.in);
      Avg a = new Avg();
       System.out.print("Enter the no of elements in the array");
   x=in.nextInt();
   int[] b = new int[x];			
    b= a.create(x);
	a.average(b);
      a.display();
}
}
class Avg
{
  
     int[] a;
     double avg;
    int[] create(int n)
    { 
       Scanner in = new Scanner(System.in);
   
   a = new int[n];
   System.out.println("Enter the elements");
   for(int i=0;i<n;i++)
   { 
     a[i]=in.nextInt();

   }
   return a;
  
  }
  void average(int[] a)
  {
	int n=a.length;
	double j=0;
     for(int i=0;i<n;i++)
	{
		j=j+a[i];	
		
	}
		avg=j/n;
  } 
   void display()
 {
    System.out.println("the average of array elements is "+avg);
 }
}