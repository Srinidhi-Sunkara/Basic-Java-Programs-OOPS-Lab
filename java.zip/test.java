import mypack.shapes.*;
import java.util.*;
public class test
{
	public static void main(String[] args)
	{
		mypack.shapes.square ob = new mypack.shapes.square();
		ob.get_input();
		System.out.println("area "+ob.area()+" perimeter "+ob.perimeter());
		mypack.shapes.triangle ob1 = new mypack.shapes.triangle();
		ob1.get_input();
		System.out.println("area "+ob1.area()+" perimeter "+ob1.perimeter());
		mypack.shapes.circle ob2 = new mypack.shapes.circle();
		ob2.get_input();
		System.out.println("area "+ob2.area()+" perimeter "+ob2.perimeter());

	}
}
