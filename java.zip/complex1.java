import java.util.Scanner;

public class complex1
{ 
   
   public static void main(String[] args)
   {
       cmp[] c;
     Scanner in = new Scanner(System.in);
     int n,i,x,y;
     System.out.print("Enter the no of complex no's:");
     n=in.nextInt();
    c= new cmp[n];
     
    for(i=0;i<n;i++)
     { 
        c[i]= new cmp();
        System.out.println("Enter the real part of"+(i+1)+"no:");
          x=in.nextInt();
         System.out.println("Enter the imaginary part of"+(i+1)+"no:");
         y=in.nextInt();
       c[i].create(x,y);   
     }
     System.out.println("List of entered complex numbers is:");
     for(i=0;i<n;i++)
     { 
         c[i].display();
         
     }	
     
  
   }
}
class cmp
{ 
   
    int real;
    int img;
    void create(int x,int y)
   {
      real=x;
      img= y;   
   }
    void display()
   {
      System.out.println(real+"+i"+img);
   }
}