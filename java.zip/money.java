import converter.*;
import java.util.*;
public class money
{
	public static void main(String[] args)
	{
		int ch;
		Scanner in = new Scanner(System.in);
		System.out.println("MENU");
		System.out.println("1.DOLLAR TO INR");
		System.out.println("2.INR TO DOLLAR");
		System.out.println("3.EURO TO INR");
		System.out.println("4.YEN TO INR");
		System.out.print("ENTER CHOICE");
		ch=in.nextInt();
		converter.currency c = new converter.currency();
		switch(ch)
		{
			case 1:{
				c.dtoin();
				break;
				}
			
			case 2:{
				c.intod();
				break;
				}
			
			case 3:{
				c.etoin();
				break;
				}
			
			case 4:{
				c.yentoinr();
				break;
				}
		}
		
				
	}
}