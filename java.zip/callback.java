interface callback{
	void call(int a);
}
class client implements callback{
	public void call(int p){
      System.out.println("callback called with"+p);

	}
}
class TestIface{
	public static void main(String[] args){
	callback obj = new client();
	obj.call(42);
	}
}