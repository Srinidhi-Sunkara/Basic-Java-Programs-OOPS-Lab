import java.util.Scanner;
public class info
{
  public static void main(String[] args)
  {
    student s;
    s=new student("srinidhi",18,112);
    s.display();
     }
}
class student
{
    String name;
    int age;
    int reg;
   student(String n,int a,int r)
   {
      name=n;
      age=a;
       reg=r;  
    } 
   void display()
    {
       System.out.println("hello "+name+" ur age is "+age+" registration number is "+reg);
    }
}
   