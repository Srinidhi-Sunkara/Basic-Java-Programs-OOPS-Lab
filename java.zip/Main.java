import java.util.Scanner;
public class Main
{
  public static void main(String[] args)
  { 
        Animal a1;
        a1=new Animal();
        a1.create();
        a1.display();     
  }
}


class Animal
{
  final String petshop="the best pet shop";
  String name;
  int age;
  String color;
   void create()
   {
      Scanner in=new Scanner(System.in);
    
     System.out.println("Enter the name of animal");
     name=in.nextLine();
     System.out.println("Enter the color of animal:");
     color=in.nextLine();
     System.out.println("Enter the age of animal:");
     age=in.nextInt();
   }
   void display()
   { 
          System.out.println("shop name:"+petshop+" \nname: "+name+"\n age: "+age+"\n color: "+color);


   }
}