import java.util.*;
 interface stack
{
	int pop();
	void push(int ele);
	void create();
	boolean isempty();
	boolean isfull();
	void display();

}
class stackim implements stack
{
	int max;
    int top;
    int[] a;
	public boolean isempty()
	{
		if (top<=-1)
		{
			System.out.println("the stack is empty");
			return true;
		}
		else
		{
			System.out.println("stack is not empty");
			return false;
		}
	}
	public boolean isfull()
	{
		if(top==max-1)
		{
			System.out.println("stack is full");
			return true;
		}
		else
		{
			System.out.println("stack is not full");
			return false;
		}
	}
	public void push(int ele)
	{
		if(isfull())
			{System.out.println("stack overflow");
		return;}
		else{
			top=top+1;
			a[top]=ele;
		}
	}


	public int pop(){
	if(isempty())
	{	
		System.out.println("stack underflow");
        return -1; 
    }
	else{
		int x = a[top];
		top=top-1;
		return x;
     }
 }

    public void create(){
	System.out.println("enter the number of elements in the stack:");
	Scanner in = new Scanner(System.in);
	max=in.nextInt();
	a = new int[max];
	top=-1;
    }
     public void display()
   {
   	if(top>-1)
	for(int i=0;i<=top;i++)
	{
		System.out.println(a[i]);
	}
   }
   
}
class testai
{
	public static void main(String[] args)
	{
		stackim s = new stackim();
		s.create();
		s.push(1);
		s.push(2);
		s.display();
	int x =	s.pop();
		System.out.println("after poping 1");
		s.display();
		x = s.pop();
			System.out.println("after poping 2");
			
			x = s.pop();
			s.display();
			if(s.isempty())
			{
				System.out.println("stack is empty");
			}
			else
			{
				System.out.println("stack is not empty");
			}
	}
}