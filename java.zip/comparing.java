import java.util.Scanner;
interface comparing{
	int compare(int a,int b);
	void compare(float a,float b);
	void compare(String a,String b);
	void sort(int a[]);
	int[] getinput();


}
class testi implements comparing
{
	public int compare(int a,int b)
	{
		    if(a>b)
			return 1;
		    else
		    return 0;
	
	}
	public void compare(float a,float b)
	{
		    if(a>b)
			System.out.println(a+" is greater");
		    else
		    	System.out.println(b+" is greater");
	
	}
	public void compare(String a,String b)
	{
		    if(a.length()>b.length())
			System.out.println(a+" is greater");
		    else
		    	System.out.println(b+" is greater");
	
	}
	public void sort(int a[])
	{
		int i,j;
		for(i=0;i<a.length;i++){
		for (j=i+1;j<a.length;j++ ) {
			if(compare(a[i],a[j])==1){
				int temp = a[i];
				a[i]=a[j];
				a[j]=temp;
			}

		}

		}
		System.out.println("");
		System.out.print("the array after the sorting is: ");
		for(i=0;i<a.length;i++){
			System.out.print(a[i]+" ");
		}

	}
	public int[] getinput()
	{
		System.out.print("enter the no of elements int the array:");
		int a[],n;
		Scanner in = new Scanner(System.in);
		n=in.nextInt();
		a= new int[n];
		int i;
		for(i=0;i<n;i++)
		{
			a[i]=in.nextInt();
		}
		System.out.print("the entered array is: ");
		for(i=0;i<n;i++)
			System.out.print(a[i]+" ");
		return a;

	}
	
}
	

class testIface{
	public static void main(String[] args)
	{
		comparing obj = new testi();
		
		obj.compare(7.2f,17.7f);
		obj.compare("srinidhi","shalumeena");
		int b[];
		b = obj.getinput();

		obj.sort(b);
	
	
	}
}