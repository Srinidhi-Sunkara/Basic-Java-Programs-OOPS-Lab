import java.util.*;
abstract class shape
{
	int base;
	int heigth;
	int radius;
	abstract void area();
}
class rectangle extends shape
{
	void area()
	{
		int area;
		Scanner in = new Scanner(System.in);
		System.out.println("enter length and height of rectangle:");
		base=in.nextInt();
		heigth=in.nextInt();
		area=(base*heigth);
		System.out.println("the area of rectangle is:"+area);
	}
}
class triangle extends shape
{
	void area()
	{
		double areat;
		Scanner in = new Scanner(System.in);
		System.out.println("enter base and height of triangle:");
		base=in.nextInt();
		heigth=in.nextInt();
		areat=(0.5*base*heigth);
		System.out.println("the area of triangle is:"+areat);
	}
}
class circle extends shape
{
     void area()
	{
		double areac;
		Scanner in = new Scanner(System.in);
		System.out.println("enter the radius of the circle:");
		radius = in.nextInt();
		areac = 3.14*radius*radius;
		System.out.println("the area of circle is:"+areac);
	}
}
public class test_abstract
{
	public static void main(String[] args)
	{
		rectangle r = new rectangle();
		r.area();
		triangle r1 = new triangle();
		r1.area();
		circle c = new circle();
		c.area();
	}
}