import java.util.Scanner;
public class Mains
{
  public static void main(String[] args)
  {
     String name;
     student s;
     Scanner in=new Scanner(System.in);
     s=new student();
     System.out.print("Enter ur name:");
     name=in.nextLine();

     s.getInfo(name);
     System.out.print("Enter ur age:");
     s.age=in.nextInt();  
     System.out.println("Entered name is: "+s.display());
     System.out.println("Entered age is: "+s.age);
  }
}
class student
{
   private String name;
   public int age;
    public void getInfo(String name)
    {
      this.name=name;
    }
    public String display()
   {
      return name;
   }
}