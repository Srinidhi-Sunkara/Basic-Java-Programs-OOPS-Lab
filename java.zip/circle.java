package mypack.shapes;
import java.util.*;
public class circle
{
	public double radius;
	
	public void get_input()
	{
		System.out.println("enter the radius:");
		Scanner in =  new Scanner(System.in);
	    radius=in.nextFloat();
		
	}
	public double area()
	{
		return (3.14*radius*radius);
 
	}
	public double perimeter()
	{
		return (2*3.14*radius);
	}
}
