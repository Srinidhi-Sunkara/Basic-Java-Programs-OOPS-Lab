package mypack.shapes;
import java.util.*;
public class square
{
	public double side;
	public void get_input()
	{
		System.out.println("enter the side of square:");
		Scanner in =  new Scanner(System.in);
		side=in.nextFloat();
	}
	public double area()
	{
		return (side*side);
 
	}
	public double perimeter()
	{
		return (4*side);
	}
}
