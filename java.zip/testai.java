import java.util.*;
public interface stack
{
	public int max=0;
	public int top=0;
	public int[] a = new int[max];

}
class stackim implements stack
{
	public void push(int ele)
	{
		if(top==max-1)
			System.out.println("stack overflow");
		else
		{
			top=top+1;
			a[top]=ele;
		}
	}


	public void pop(){
	if(top==-1)
		System.out.println("stack underflow");
	else
		top=top-1;
     }

    public void create(){
	System.out.println("enter the number of elements in the stack:");
	Scanner in = new Scanner(System.in);
	max=in.nextInt();
	top=-1;
    }
     public void display()
   {
	for(int i=0;i<top;i++)
	{
		System.out.println(a[i]);
	}
   }
}
class testai
{
	public static void main(String[] args)
	{
		stackim s = new stackim();
		s.create();
		s.push(1);
		s.push(2);
		s.display();
		s.pop();
		s.display();
	}
}