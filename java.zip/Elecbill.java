/*import java.util.Scanner;
public class Elecbill{
    
    public static void main(String[] args){
         Scanner in = new Scanner(System.in);
         eb e;
         int type;
        System.out.print("enter 0 if domestic and 1 for commercial");
        type=in.nextInt();
        
        System.out.print("enter the consumer no:");
       int no=in.nextInt();
        System.out.print("enter the consumer name:");
       String name=in.next();
        System.out.print("enter the previous month reading:");
       int p=in.nextInt();
        System.out.print("enter the current month reading:");
       int c=in.nextInt();
        e = new eb(type,p,c);
e.consumer_name=name;
e.consumer_no=no;

        e.display();

      
    }
}
class eb{
    int consumer_no;
    String consumer_name;
    int pmr;
    int cmr;
    int r;
    double t;
        
    eb(int a,int p,int c){
   
      
      r=c-p;
      if(a==0){
        if(r<=100)
            t=(r*1);
        else if(r>100&&r<=200)
            t=100+((r-100)*2.5);
        else if(r>200&&r<=500)
            t=350+((r-200)*4);
        else if(r>500)
            t=1550+((r-500)*6);
        

      }
      else if(a==1){
        if(r<=100)
            t=(r*2);
        else if(r>100&&r<=200)
            t=200+((r-100)*4.5);
        else if(r>200&&r<=500)
            t=650+((r-200)*6);
        else if(r>500)
            t=2450+((r-500)*6);
           }

     }
     void display()
     {
         System.out.println("hi "+consumer_name+" no: "+ consumer_no);
         System.out.println("the total amount to be paid is "+t);
      }
}*/
import java.util.*;
class eb
{
    int consumer_no;
    String consumer_name;
    int prev_month_reading;
    int curr_month_reading;
    String type;
    double total;
    void input()    
    {
        Scanner ip = new Scanner(System.in);
        System.out.println("Electricity Bill");
        System.out.println("Enter the customer name:");
        consumer_name = ip.nextLine();
        System.out.println("Enter the customer number:");
        consumer_no = ip.nextInt();
        System.out.println("Enter the previous month reading:");
        prev_month_reading = ip.nextInt();
        System.out.println("Enter the current month reading:");
        curr_month_reading = ip.nextInt();
        System.out.println("Enter the type of Electricity Bill:");
        type = ip.next();
    }

void calculate()
{
    int choice;
        if(type=="domestic")
            choice=1;
        else
            choice=2;
        switch(choice)
        { 
        case 1:  
        {
        int diff= curr_month_reading-prev_month_reading;
       
        if(diff<=100)
        {
            total=diff;
           
        }
        else if((diff>100)&&(diff<=200))
        {
            total=100+((diff-100)*2.5);
            
        }
        else if((diff>200)&&(diff<=500))
        {
            total=350+((diff-200)*4);
           
        }
        else if(diff>500)
        {
            total=1550+((diff-500)*6);
           
        }
    
        break;
       }
    case 2:
       {
        int diff= curr_month_reading-prev_month_reading;
       
        if(diff<=100)
        {
            total=diff*2;
           
        }
        else if((diff>100)&&(diff<=200))
        {
            total=200+((diff-100)*4.5);
           
        }
        else if((diff>200)&&(diff<=500))
        {
            total=650+((diff-200)*6);
           
        }
        else if(diff>500)
        {
            total=2450+((diff-500)*7);
         
        }
           
           break;
        }
   }
}
void display()
{
    System.out.println("the amount to be paid is"+total);
}


 }
public class Elecbill
{
    public static void main(String[] args)
    {
        int ch;
        Scanner in = new Scanner(System.in);
        eb obj = new eb();
        obj.input();
        obj.calculate();
         obj.display();



    }
}



















