/*import java.util.Scanner;

public class Complex
{ 
   
   public static void main(String[] args)
   {
       cmp[] c;
     Scanner in = new Scanner(System.in);
     int n,i;
     System.out.print("Enter the no of complex no's:");
     n=in.nextInt();
    c= new cmp[n];
     
    for(i=0;i<n;i++)
     { 
        c[i]= new cmp();
         System.out.println("Enter the real part of"+(i+1)+"no:");
         c[i].real=in.nextInt();
         System.out.println("Enter the imaginary part of"+(i+1)+"no:");
         c[i].img=in.nextInt();
     }
System.out.println("List of entered complex numbers is:");
     for(i=0;i<n;i++)
     { 
         System.out.println(c[i].real+"+i"+c[i].img);
         
     }	
     
     
  
   }
}
class cmp
{ 
   
    int real;
    int img;
    
}*/
import java.util.Scanner;
class complex
{
    int real;
    int imaginary;
   void get_input(){
        Scanner in = new Scanner(System.in);
        System.out.print("enter the real and imaginary parts:");
        real = in.nextInt();
        imaginary=in.nextInt();
    }
    complex add(complex obj1,complex obj2)
    {
        complex obj = new complex();
        real=obj.real=obj1.real+obj2.real;
        imaginary=obj.imaginary=obj1.imaginary+obj2.imaginary;
        return obj;
    }
    void display()
    {
        System.out.println("the addition of complex numbers is "+real+"i"+imaginary);
    }
}
public class Complex
{
    public static void main(String[] args)
    {
        complex obj1 = new complex();
        complex obj2 = new complex();
        obj1.get_input();
        obj2.get_input();
        complex obj = new complex();
        System.out.print(obj.add(obj1,obj2));
        obj.display();

    }
}



































