import java.util.*;
class co_ordinates
{
	int x;
	int y;
	void getinput()
	{
		Scanner in = new Scanner(System.in);
		 System.out.println("enter x point");
	   
           x=in.nextInt();
	  
           System.out.println("enter y point");
	   
           y=in.nextInt();
	 
	}
}
class caldis extends line
{
	double dis;
	double points(int x1,int y1,int x2,int y2)
	{
		dis=(Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)));
		return dis;	
	}
}
class slope extends line
{
	double slope;
	double points(int x1,int y1,int x2,int y2)
	{
		slope=(y2-y1)/(x2-x1);
		return slope;
	}
}
abstract class line
{
	abstract double distance(int x1,int y1,int x2,int y2);
	abstract double slope(int x1,int y1,int x2,int y2);

        
}
public class lines
{
	public static void main(String[] args)
	{
		co_ordinates fp = new co_ordinates();
		co_ordinates sp = new co_ordinates();
		caldis d = new caldis();
		slope s = new slope();
		fp.getinput();
		sp.getinput();
		System.out.println("the distance between the two points is:"+d.points(fp.x,fp.y,sp.x,sp.y));
		System.out.println("the  slope of two points is:"+s.points(fp.x,fp.y,sp.x,sp.y));		
	}
}