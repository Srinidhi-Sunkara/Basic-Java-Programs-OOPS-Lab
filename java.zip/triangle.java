package mypack.shapes;
import java.util.*;
public class triangle
{
	public double s1;
	public double s2;
	public double s3;
	public void get_input()
	{
		System.out.println("enter the s1,s2 and s3 of triangle:");
		Scanner in =  new Scanner(System.in);
	    s1=in.nextFloat();
		s2=in.nextFloat();
		s3=in.nextFloat();
	}
	public double area()
	{
		double s;
		s=(s1+s2+s3)/2;
		return (Math.sqrt(s*(s-s1)*(s-s2)*(s-s3)));
 
	}
	public double perimeter()
	{
		return (s1+s2+s3);
	}
}
